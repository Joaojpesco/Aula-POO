package ex1173;

public class Vetor {
    int num;

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }
    public Vetor(){
        
        
    }
    public int Duplica(){
        int value = this.num;
        value = value *2;
        return value;
    }
}
